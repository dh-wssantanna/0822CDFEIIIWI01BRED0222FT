import Formulario from "./componentes/Formulario";

export default function App() {

	return (
		<>
			<div className="container my-5">
				<Formulario />
			</div>
		</>
	)
}
